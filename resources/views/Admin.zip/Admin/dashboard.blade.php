@include('Include.appadmin')

<style>
    /* ── Design tokens (shared with appadmin) ─────────────────── */
    :root {
        --card:       #FFFFFF;
        --ink:        #0B1220;
        --ink-2:      #4A5772;
        --ink-3:      #8893AB;
        --danger:     #E5484D;
        --danger-bg:  #FFF1F1;
        --danger-bd:  #F4B6B6;
        --good:       #2E9E6E;
    }

    /* ── Page header ──────────────────────────────────────────── */
    .dash-head {
        display: flex; align-items: flex-end; justify-content: space-between;
        gap: 16px; flex-wrap: wrap;
    }
    .dash-title { margin: 0; font-size: 24px; font-weight: 700; letter-spacing: -0.02em; }
    .dash-title .accent { color: var(--orange); }
    .dash-sub { color: var(--on-dark-2); font-size: 13px; margin-top: 4px; }

    /* ── KPI grid ─────────────────────────────────────────────── */
    .kpi-grid { display: grid; grid-template-columns: repeat(4,1fr); gap: 14px; }

    .kpi-card {
        background: var(--card); color: var(--ink);
        border-radius: 14px;
        padding: 18px 20px 16px;
        border: 1px solid rgba(0,0,0,0.04);
        display: flex; flex-direction: column; gap: 6px;
        min-height: 120px;
    }
    .kpi-card.danger { background: var(--danger-bg); border-color: var(--danger-bd); }

    .kpi-label {
        font-size: 11px; font-weight: 600;
        letter-spacing: 0.10em; text-transform: uppercase;
        color: var(--ink-3);
    }
    .kpi-card.danger .kpi-label { color: #B5302A; }
    .kpi-value { font-size: 38px; font-weight: 700; letter-spacing: -0.02em; line-height: 1.05; }
    .kpi-foot  { font-size: 12px; color: var(--ink-2); margin-top: auto; }

    /* ── Schools table card ───────────────────────────────────── */
    .dash-card {
        background: var(--card); color: var(--ink);
        border-radius: 14px;
        border: 1px solid rgba(0,0,0,0.04);
        overflow: hidden;
    }
    .dash-card-head {
        padding: 16px 20px 14px;
        border-bottom: 1px solid #EEF0F4;
        display: flex; align-items: center; justify-content: space-between;
    }
    .dash-card-head h3 { margin: 0; font-size: 14px; font-weight: 700; }
    .dash-card-head .sub { color: var(--ink-3); font-size: 12px; }

    table.dash-tbl { width: 100%; border-collapse: collapse; }
    table.dash-tbl thead th {
        text-align: left;
        font-size: 11px; font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase;
        color: var(--ink-3);
        padding: 11px 20px;
        background: #FBFBFD;
        border-bottom: 1px solid #EEF0F4;
    }
    table.dash-tbl tbody td {
        padding: 13px 20px;
        border-bottom: 1px solid #F2F3F7;
        font-size: 13.5px;
        vertical-align: middle;
    }
    table.dash-tbl tbody tr:last-child td { border-bottom: 0; }
    table.dash-tbl tbody tr:hover { background: #FAFBFD; }

    /* quit-rate bar */
    .qbar-wrap { display: flex; align-items: center; gap: 10px; }
    .qbar-pct  { font-weight: 600; font-size: 13px; width: 36px; text-align: right; }
    .qbar { width: 80px; height: 6px; background: #EFF1F6; border-radius: 999px; overflow: hidden; }
    .qbar > span { display: block; height: 100%; border-radius: inherit; }
    .qbar-good  > span { background: var(--good); }
    .qbar-mid   > span { background: var(--orange); }
    .qbar-warn  > span { background: var(--danger); }

    /* ── Chart card ───────────────────────────────────────────── */
    .chart-wrap { padding: 20px; }

    /* ── Footnote ─────────────────────────────────────────────── */
    .dash-foot { font-size: 12px; color: var(--on-dark-2); }

    @media (max-width: 1100px) { .kpi-grid { grid-template-columns: repeat(2,1fr); } }
    @media (max-width: 640px)  { .kpi-grid { grid-template-columns: 1fr; } }
</style>

{{-- ── Page header ──────────────────────────────────────────── --}}
<div class="dash-head">
    <div>
        <h1 class="dash-title">
            Dashboard — <span class="accent">{{ $clinicName }}</span>
        </h1>
        <div class="dash-sub">Overview of patients enrolled in the school-based quit-smoking programme.</div>
    </div>
</div>

{{-- ── KPI cards ─────────────────────────────────────────────── --}}
@php
    $activeUsers = $totalUsers - $totalQuitUsers;
    $quitRate    = $totalUsers > 0 ? round(($totalQuitUsers / $totalUsers) * 100) : 0;
    $schoolCount = $schools->count();
    $avgPerSchool = $schoolCount > 0 ? number_format($totalUsers / $schoolCount, 1) : '—';
@endphp

<div class="kpi-grid">
    <div class="kpi-card">
        <div class="kpi-label">Total Users</div>
        <div class="kpi-value">{{ $totalUsers > 0 ? $totalUsers : '—' }}</div>
        <div class="kpi-foot">across {{ $schoolCount }} schools</div>
    </div>
    <div class="kpi-card">
        <div class="kpi-label">Active Patients</div>
        <div class="kpi-value">{{ $activeUsers > 0 ? $activeUsers : '—' }}</div>
        <div class="kpi-foot">still smoke-free</div>
    </div>
    <div class="kpi-card danger">
        <div class="kpi-label">Quit Users</div>
        <div class="kpi-value">{{ $totalQuitUsers > 0 ? $totalQuitUsers : '—' }}</div>
        <div class="kpi-foot">{{ $quitRate }}% overall quit rate</div>
    </div>
    <div class="kpi-card">
        <div class="kpi-label">Avg per School</div>
        <div class="kpi-value">{{ $avgPerSchool }}</div>
        <div class="kpi-foot">patients per school</div>
    </div>
</div>

{{-- ── Schools table ─────────────────────────────────────────── --}}
<div class="dash-card">
    <div class="dash-card-head">
        <div>
            <h3>Users per School</h3>
        </div>
        <span class="sub">{{ $schoolCount }} schools</span>
    </div>
    <table class="dash-tbl">
        <thead>
            <tr>
                <th>School</th>
                <th style="text-align:right;">Enrolled</th>
                <th style="width:200px;">Quit Rate</th>
            </tr>
        </thead>
        <tbody>
            @forelse($schools as $school)
            @php
                $cnt = $school->users_count;
                $qCount = \App\Models\User::where('school_id', $school->id)
                    ->whereIn('id', function($q) {
                        $q->select('user_id')->from('badge_user')->where('badge_id', 4);
                    })->count();
                $pct = $cnt > 0 ? round(($qCount / $cnt) * 100) : 0;
                $barCls = $pct >= 50 ? 'qbar-warn' : ($pct >= 20 ? 'qbar-mid' : 'qbar-good');
            @endphp
            <tr>
                <td style="font-weight:600;">{{ $school->name }}</td>
                <td style="text-align:right;color:var(--ink-2);">{{ $cnt }}</td>
                <td>
                    <div class="qbar-wrap">
                        <div class="qbar {{ $barCls }}"><span style="width:{{ $pct }}%"></span></div>
                        <span class="qbar-pct">{{ $pct }}%</span>
                    </div>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="3" style="text-align:center;color:var(--ink-3);padding:28px;">No schools found.</td>
            </tr>
            @endforelse
        </tbody>
    </table>
</div>

{{-- ── Check-ins chart ───────────────────────────────────────── --}}
<div class="dash-card">
    <div class="dash-card-head">
        <div><h3>Check-Ins per Day</h3></div>
        <span class="sub">smoke-free vs smoked</span>
    </div>
    <div class="chart-wrap">
        <canvas id="checkInsChart" height="90"></canvas>
    </div>
</div>

<div class="dash-foot">
    Last sync on page load · Data scope: patients under {{ $clinicName }} only · Records comply with PDPA 2010.
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
(function () {
    const ctx = document.getElementById('checkInsChart').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: {!! json_encode($checkInLabels) !!},
            datasets: [
                {
                    label: 'Not Smoke',
                    data: {!! json_encode($greenCounts) !!},
                    backgroundColor: 'rgba(46,158,110,0.75)',
                    borderRadius: 4,
                },
                {
                    label: 'Smoked',
                    data: {!! json_encode($redCounts) !!},
                    backgroundColor: 'rgba(229,72,77,0.75)',
                    borderRadius: 4,
                }
            ]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { position: 'top', labels: { color: '#8893AB', font: { size: 12 } } }
            },
            scales: {
                x: {
                    stacked: true,
                    ticks: { color: '#8893AB', font: { size: 11 } },
                    grid:  { color: 'rgba(255,255,255,0.05)' }
                },
                y: {
                    stacked: true,
                    beginAtZero: true,
                    ticks: { color: '#8893AB', font: { size: 11 } },
                    grid:  { color: 'rgba(255,255,255,0.05)' }
                }
            }
        }
    });
})();
</script>

@include('Include.footer')
